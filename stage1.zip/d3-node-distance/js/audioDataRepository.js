var AudioDataRepository = new function() {
	
	// TODO: API Call
	this.getData = function() {
		return this._data;
	};


	this._data = [];
}